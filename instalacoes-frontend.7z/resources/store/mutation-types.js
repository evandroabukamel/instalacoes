// AUTH
export const LOGIN = "LOGIN";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGOUT = "LOGOUT";

// APP - DEVICE
export const TOGGLE_DEVICE = 'TOGGLE_DEVICE';
export const TOGGLE_SIDEBAR = 'TOGGLE_SIDEBAR';
export const EXPAND_MENU = 'EXPAND_MENU';
export const SWITCH_EFFECT = 'SWITCH_EFFECT';
