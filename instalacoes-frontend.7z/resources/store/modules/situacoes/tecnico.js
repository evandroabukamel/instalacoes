// SITUACOES TECNICO COPIADO DO BACK-END
const ATIVO = 19;
const INATIVO = 20;
const PENDENTE = 21;
const EXCLUIDO = 22;

const tecnico = {
	ATIVO,
	INATIVO,
	PENDENTE,
	EXCLUIDO
}

export default tecnico;