// SITUACOES EMPRESA COPIADO DO BACK-END
const ATIVA = 23;
const INATIVA = 24;
const PENDENTE = 25;
const EXCLUIDA = 26;

const empresa = {
	ATIVA,
	INATIVA,
	PENDENTE,
	EXCLUIDA
}

export default empresa;