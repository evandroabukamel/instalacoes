import agendamento from './agendamento.js';
import empresa from './empresa.js';
import tecnico from './tecnico.js';

const situacoes = {
	state: {
		agendamento,
		empresa,
		tecnico
	},
	getters: {
		situacaoAgendamento: (state) => {
			return state.agendamento
		},
		situacaoEmpresa: (state) => {
			return state.empresa
		},
		situacaoTecnico: (state) => {
			return state.tecnico
		}
	}
}

export default situacoes;