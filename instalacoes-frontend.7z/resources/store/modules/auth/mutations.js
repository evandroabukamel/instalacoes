import * as types from '../../mutation-types.js';

let mutations = {
	[types.LOGIN](state) {
		state.pending = true;
		state.dadosUsuario = {};
	},
	[types.LOGIN_SUCCESS](state) {
		state.pending = false;
		state.isLoggedIn = true;
		state.dadosUsuario = JSON.parse(localStorage.getItem("dadosUsuario"));
	},
	[types.LOGOUT](state) {
		state.pending = false;
		state.isLoggedIn = false;
		state.dadosUsuario = {};
	}
};

export default mutations;