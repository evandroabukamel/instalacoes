<template>
	<section class="is-white hero app-navbar animated" :class="{ slideInDown: show, slideOutDown: !show }">
		<div class="hero-head">
			<nav class="navbar container is-white" role="navigation" :class="{ slideInDown: show, slideOutDown: !show }">
				<!-- This "nav-burger" hamburger menu is only visible on mobile -->
				<!-- You need JavaScript to toggle the "is-active" class on "nav-menu" -->
				<div class="navbar-burger burger is-pulled-left is-marginless" 
					data-target="navMenu"
					@click="toggleMobileMenu">
					<span></span>
					<span></span>
					<span></span>
				</div>
				<div class="navbar-brand">
					<router-link to="/" class="navbar-item" exact>
						<img src="../../../static/assets/images/logo.png" alt="GTS Soluções">
					</router-link>
				</div>
				<!-- This "nav-menu" is shown on mobile -->
				<div v-show="!isLoggedIn" id="navMenu" class="navbar-menu" :class="{'is-active': mobileMenuActive}">
					<div class="navbar-end">
						<!-- MENUS PÚBLICOS -->
						<router-link to="/" class="navbar-item is-tab" @click.default="closeMobileMenu" exact>
							Home
						</router-link>
						<router-link to="/cadastrar" class="navbar-item is-tab" @click.default="closeMobileMenu">
							Cadastrar
						</router-link>
						<!-- MENUS INTRANET -->
						<router-link to="/login" class="navbar-item is-tab" @click.default="closeMobileMenu">
							Entrar
						</router-link>
					</div>
				</div>
			</nav>
		</div>
	</section>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
	props: {
		show: Boolean
	},
	data() {
		return {
			mobileMenuActive: false
		}
	},
	computed: {
		...mapGetters([
			'isLoggedIn',
			'isLoading',
			'sidebar'
		])
	},
	methods: {
		...mapActions([
			'toggleSidebar'
		]),
		toggleMobileMenu() {
			this.mobileMenuActive = !this.mobileMenuActive;
			this.toggleSidebar(!this.sidebar.opened);
		},
		closeMobileMenu() {
			this.mobileMenuActive = false;
		}
	}
}
</script>

<style lang="scss">
.app-navbar {
	position: fixed;
	top: 0;
	left: 0;
	min-width: 100%;
	z-index: 100;
	box-shadow: 0 2px 3px rgba(17, 17, 17, 0.1), 0 0 0 1px rgba(17, 17, 17, 0.1);
}
</style>