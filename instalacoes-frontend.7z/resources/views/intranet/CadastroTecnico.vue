<template>
	<div class="columns is-centered">
		<div class="column">
			<h1 class="title is-clearfix" v-html="'Cadastro de t&eacute;cnico'"></h1>
			<b-message :closable="false">
				<form name="cadastroTecnicoForm" method="post" action="#"
					@submit.prevent="onSubmit"
					@keydown="form.errors.clear($event.target.name)"
					@change="form.errors.clear($event.target.name)">
					<div class="columns">
						<div class="column is-half-desktop">
							<h2 class="subtitle"><span v-html="'Dados do t&eacute;cnico'"></span></h2>
							<input-autocomplete v-if="showAutocompleteEmpresa"
								ref="autocompleteEmpresa"
								label="Empresa"
								placeholder="Buscar empresa"
								name="empresa"
								size="is-medium"
								:url="urlAutocompleteEmpresa"
								param=""
								:init-value="form.empresa ? form.empresa.nome : null"
								field="nome"
								subtitle="cpfcnpj"
								field-label="Nome"
								subtitle-label="CPF/CNPJ"
								:minlength="2"
								@selected="setEmpresa"
								:error="form.errors.get('marcaVeiculo')">
							</input-autocomplete>
							<input-text name="nome" v-model="form.nome" 
								placeholder="Nome" size="is-medium"
								:has-error="form.errors.has('nome')"
								:error="form.errors.get('nome')"></input-text>
							<input-text name="cpf" v-model="form.cpf" 
								type="tel"
								placeholder="CPF / CNPJ" size="is-medium"
								:mask="['###.###.###-##', '##.###.###/####-##']"
								:has-error="form.errors.has('cpf')"
								:error="form.errors.get('cpf')"></input-text>
							<select-ajax name="idSituacao" v-model="form.idSituacao"
								v-if="form.id > 0 && showSelectSituacao"
								placeholder="Situação" size="is-medium"
								api-route="/tecnico/listarSituacoes"
								control-type="is-primary"
								:has-error="form.errors.has('idSituacao')"
								:error="form.errors.get('idSituacao')"
								v-on:errorSelectAjax="form.setSelectError('idSituacao', $event)">
							</select-ajax>
							<div class="field" v-if="form.id && !showSelectSituacao">
								<label class="label" v-html="'Situa&ccedil;&atilde;o'"></label>
								<h2 class="subtitle">{{ form.situacaoDescricao }}</h2>
							</div>
							<input-text name="raioAtendimento" v-model="form.raioAtendimento" 
								size="is-medium"
								type="number"
								:min="0"
								placeholder="Raio de atendimento (km)"
								:has-error="form.errors.has('raioAtendimento')"
								:error="form.errors.get('raioAtendimento')"></input-text>
						</div>
						<div class="column is-half-desktop">
							<!-- Agenda -->
							<h2 class="subtitle">Agenda semanal</h2>
							<input-agenda name="agenda" v-on:add="addAgenda($event)"
								size="is-medium"
								:has-error="form.errors.has('agendas')"
								:error="form.errors.get('agendas')"></input-agenda>
							<lista-agenda v-model="form.agendas"></lista-agenda>
							<!-- Contatos -->
							<h2 class="subtitle">Contatos</h2>
							<input-contato name="contato" v-on:add="form.addContato($event)"
								size="is-medium"
								:has-error="form.errors.has('contatos')"
								:error="form.errors.get('contatos')"></input-contato>
							<div></div>
							<lista-contato v-model="form.contatos"></lista-contato>
						</div>
					</div>
					<!-- FormUsuario -->
					<!-- Só mostra o form-usuário se for um registro diferente do usuário logado -->
					<form-usuario ref="formUsuario" name="usuario"
						v-if="showFormUsuario"
						size="is-medium"
						v-model="form.usuario"
						@changed="form.errors.clear($event, 'usuario')"
						:has-error="form.errors.has('usuario')"
						:error="form.errors.get('usuario')"></form-usuario>
					<div class="columns">
						<div class="column is-half-desktop">
							<!-- Localização -->
							<h2 class="subtitle"><span v-html="'Localiza&ccedil;&atilde;o'"></span></h2>
							<!-- FormEndereco -->
							<form-endereco ref="formEndereco" name="endereco"
								size="is-medium"
								v-model="form.endereco"
								@changed="form.errors.clear($event, 'endereco')"
								:has-error="form.errors.has('endereco')"
								:error="form.errors.get('endereco')"></form-endereco>
						</div>
						<div class="column is-half-desktop">
							<!-- Mapa -->
							<here-maps ref="hereMap"
								@clickBuscarPosicao="buscarEnderecoPosicao"
								@markerPositioned="atualizaEnderecoPosicao($event)"></here-maps>
							<div></div>
						</div>
					</div>
					<!-- Botões -->
					<div class="field has-addons has-addons-right">
						<div class="control">
							<button type="button" class="button is-primary is-medium"
								:class="{ 'is-loading': form.isLoading }"
								@click="onSubmit"
								@dblclick.prevent>
								Salvar
							</button>
						</div>
					</div>
				</form>
			</b-message>
		</div>
	</div>
</template>

<script>
import Endereco from '../../core/Endereco.js';
import FormEndereco from '../../components/FormEndereco.vue';
import FormUsuario from '../../components/FormUsuario.vue';
import HereMaps from '../../components/HereMaps.vue';
import InputAgenda from '../../components/InputAgenda.vue';
import InputAutocomplete from '../../components/InputAutocomplete.vue';
import InputContato from '../../components/InputContato.vue';
import ListaAgenda from '../../components/ListaAgenda.vue';
import ListaContato from '../../components/ListaContato.vue';
import { mapGetters, mapActions } from 'vuex';

export default {
	components: { InputAutocomplete, InputContato, ListaContato, InputAgenda, ListaAgenda, 
		HereMaps, FormEndereco, FormUsuario },
	data() {
		return {
			form: new Form({
				id: null,
				idSituacao: null,
				situacaoDescricao: null,
				empresa: null,
				nome: '',
				cpf: '',
				raioAtendimento: null,
				agendas: [],
				contatos: [],
				endereco: {},
				usuario: {}
			}),
			showAutocompleteEmpresa: true,
			showFormUsuario: this.$route.name == 'cadastro-tecnico',
			showSelectSituacao: true
		}
	},

	computed: {
		...mapGetters([
			'dadosUsuario',
			'situacaoTecnico'
		]),

		urlAutocompleteEmpresa() {
			return '/empresa/findLike';
		}
	},
	
	methods: {
		/**
		 * Oculta o select de situação se o role não for ROLE_MATRIZFILIAL e a situação for PENDENTE.
		 */
		/*showSelectSituacao() {
			return !(!_.includes(this.dadosUsuario.roles, 'ROLE_MATRIZFILIAL') && this.form.idSituacao == 21);
		},*/

		setEmpresa(obj) {
			// Atribui o id da empresa de um obj recebido
			if (obj && parseInt(obj.id) > 0) {
				this.form.empresa = obj;
			}
		},

		addAgenda(agenda) {
			// Variável flag para erros de conflito de horários
			let error = false;
			// Separa as agenda do mesmo dia da agenda a ser adicionada e ordena pelo horario inicial
			let agendasDia = _.sortBy(_.filter(this.form.agendas, (o) => o.diaSemana === agenda.diaSemana), [(o) => o.horarioInicial]);
			// Verifica se a lista está vazia
			if (agendasDia.length > 0) {
				// Verifica se o novo horário já existe na agenda
				for (let i = 0; i < agendasDia.length; i++) {
					if ((agenda.diaSemana === agendasDia[i].diaSemana) &&
						((agenda.horarioInicial >= agendasDia[i].horarioInicial && agenda.horarioInicial <= agendasDia[i].horarioFinal) ||
						(agenda.horarioFinal >= agendasDia[i].horarioInicial && agenda.horarioFinal <= agendasDia[i].horarioFinal))) {
						error = true;
						break;
					}
					else {
						error = false;
					}
				}

				// Se houve erro, mostra a mensagem
				if (error) {
					this.form.errors.add('agendas', 'Conflito de horários, parte desse horário já está na agenda.');
				}
				else {
					// Senão, adiciona o horário
					this.form.agendas.push(agenda);
					this.form.errors.clear('agendas');
				}
			}
			else {
				// Adiciona o primeiro horário, com a lista vazia
				this.form.agendas.push(agenda);
				this.form.errors.clear('agendas');
			}

			// Reordena a lista da agenda do dia da semana
			this.form.agendas = _.sortBy(this.form.agendas, ['diaSemana', 'horarioInicial']);
		},

		buscarEnderecoPosicao() {
			this.form.errors.clear('posicao', 'endereco');

			let position = null;

			// Busca a posição para o endereço
			if (this.form.endereco.toMapString() != '') {
				this.$refs.hereMap.searchPositionForAddress(this.form.endereco.toMapString())
				.then(response => {
					// adiciona o marcador
					this.$refs.hereMap.addUniqueMarker(null, {
						position: {
							lat: response.Latitude,
							lng: response.Longitude
						},
						draggable: true
					})
				})
				.catch(response => {
				});
			}
		},

		atualizaEnderecoPosicao(posicao) {
			this.form.errors.clear('posicao', 'endereco');
			this.form.endereco.posicao = { latitude: posicao.lat, longitude: posicao.lng };
		},

		onSubmit() {
            this.form.post('/tecnico/salvar')
			.then(response => {
				if (response.message) {
					this.$toast.open({
						message: response.message ? response.message :  'Cadastro salvo com sucesso.',
						type: 'is-success',
						position: 'is-top',
						duration: 5000
					});
					this.$router.push('/lista-tecnico');
				}
			})
            .catch(error => {
				if (error.message){
					this.$toast.open({
						message: error.message ? error.message :  'Erro ao salvar cadastro.',
						type: 'is-warning',
						position: 'is-top',
						duration: 7000
					});
				}
			});
		},

		setFormData(response, error) {
			if (error) {
				if (error.response.data.message){
					this.$toast.open({
						message: error.response.data.message ? error.response.data.message :  'Erro ao consultar cadastro.',
						type: 'is-warning',
						position: 'is-top',
						duration: 5000
					});
				}
			}
			else {
				this.form.reset();
				for (let field in _.omit(this.form.data(), ['contatos','endereco','empresa','usuario'])) {
					this.form[field] = response.data[field];
				}

				// Controla a exibição do select de Situação
				this.showSelectSituacao = !(!_.includes(this.dadosUsuario.roles, 'ROLE_MATRIZFILIAL') 
					&& response.data.idSituacao == this.situacaoTecnico.PENDENTE)

				// Obtém os objetos contatos
				this.form.contatos = this.form.loadContatos(response.data.contatos);
				// Obtém o objeto endereco
				this.form.endereco = this.form.loadEndereco(response.data.endereco);
				// Formata os objeto usuario
				if (this.showFormUsuario) {
					this.form.usuario = this.form.loadUsuario(response.data.usuario);
					this.$refs.formUsuario.showPasswordField = false;
				}
				
				// Obtém o objeto empresa
				this.setEmpresa(response.data.empresa);

				// Marca o ponto do endereço no mapa
				if (response.data.endereco && response.data.endereco.posicao) {
					// adiciona o marcador
					this.$refs.hereMap.addUniqueMarker(null, {
						position: {
							lat: response.data.endereco.posicao.latitude,
							lng: response.data.endereco.posicao.longitude
						},
						draggable: true
					})
				}
			}
		}
	},

	created() {
		// Verifica a necessidade de exibir o campos de buscar empresa
		if (this.dadosUsuario.classe == 'tbempresa') {
			this.form.empresa = { id: this.dadosUsuario.idObjeto };
			if (this.form.empresa.id > 0) this.showAutocompleteEmpresa = false;
		}
		else if (this.dadosUsuario.classe == 'tbtecnico') {
			this.showAutocompleteEmpresa = false;
			delete this.form.empresa;
		}
	},
	
	beforeRouteEnter (to, from, next) {
		let id;

		// Obtem o ID vindo nos parâmetros da route
		if (to.params.id) {
			id = to.params.id;
		} else if (typeof(to.meta.id) == 'function') {
			id = to.meta.id();
		}
		
		if (id) {
			Vue.axios.get('/tecnico/findId/' + id)
			.then(response => {
				next(vm => {
					vm.setFormData(response, null); 
				} );
			})
			.catch(error => {
				next(vm => {
					vm.setFormData(null, error); 
				} );
			});
		} else {
			next(vm => {
				vm.form.reset(); 
				if (vm.form.empresa) {
					vm.form.empresa = vm.dadosUsuario.classe == 'tbempresa' 
						? { id: vm.dadosUsuario.idObjeto } 
						: null;
					if (vm.form.empresa.id > 0) vm.showAutocompleteEmpresa = false;
				}
				vm.$refs.hereMap.clearMarkers();
			});
		}
	},

	// Quando a route muda e este componente já está renderizado, a lógica é diferente
	beforeRouteUpdate (to, from, next) {
		this.form.reset();
		this.$refs.hereMap.clearMarkers();
		let id;

		// Obtem o ID vindo nos parâmetros da route
		if (to.params.id) {
			id = to.params.id;
		} else if (typeof(to.meta.id) == 'function') {
			id = to.meta.id();
		}
		
		if (id) {
			this.axios.get('/tecnico/findId/' + id)
			.then(response => {
				this.setFormData(response, null);
				next();
			})
			.catch(error => {
				this.setFormData(null, error);
				next();
			});
		} else {
			if (this.form.empresa) {
				this.form.empresa = this.dadosUsuario.classe == 'tbempresa' 
					? { id: this.dadosUsuario.idObjeto } 
					: null;
				if (this.form.empresa.id > 0) this.showAutocompleteEmpresa = false;
			}
			next();
		}
	}
}
</script>