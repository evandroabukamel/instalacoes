module.exports = {
  NODE_ENV: '"production"',
  API_URL: '"./api.php"'
}
